<?php

return [
		'env' => 'development',
		'user_type' => [
				//"0" => "",
				"1" => "Individual",
				"2" => "Business"
		],
		'user_status' => [
				"0" => "Pending",
				"1" => "Approved",
				"2" => "Suspended"
		],
		'ad_status' => [
				"0" => "Pending",
				"1" => "Approved",
				//"2" => "Archived"
		],
];