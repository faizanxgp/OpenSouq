<html>
<head></head>
<body style="background-color: #f0f0f0; color: #262626; padding: 10px;">
<div>
	{!! $content !!}
</div>
</body>
</html>