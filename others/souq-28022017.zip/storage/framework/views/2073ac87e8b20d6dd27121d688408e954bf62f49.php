<?php $__env->startSection('content'); ?>
  <div class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-sm-3 page-sidebar">
          <?php echo $__env->make('partials.user-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
        </div>
        <!--/.page-sidebar-->
        
        <div class="col-sm-9 page-content">
          <div class="inner-box">
            <h2 class="title-2"><i class="icon-docs"></i>  </h2>
            
            <div class="table-responsive">
              <div class="table-action">
                <label for="checkAll">
                  <input type="checkbox" id="checkAll">
                  Select: All | <a class="btn btn-xs btn-danger" href="#">Delete <i
                        class="glyphicon glyphicon-remove "></i></a> </label>
                
                <div class="table-search pull-right col-xs-7">
                  <div class="form-group">
                    <label class="col-xs-5 control-label text-right">Search <br>
                      <a href="#clear" class="clear-filter" title="clear filter">[clear]</a>
                    </label>
                    
                    <div class="col-xs-7 searchpan">
                      <input type="text" id="filter" class="form-control">
                    </div>
                  </div>
                </div>
              </div>
				<h2> <?php echo e($list_title); ?> </h2>
                <?php foreach($messages as $msg): ?>
					<div class="message <?php if($msg->sender==1): ?> blue <?php else: ?> green pull-right <?php endif; ?>">
						<div><?php if($msg->sender==1): ?> <?php echo e($list_user_name); ?> <?php else: ?> <?php echo e($user_name); ?> <?php endif; ?>
							<?php echo e($msg->created_at); ?>

						</div>
						<div><?php echo e($msg->description); ?></div>
					</div>
                <?php endforeach; ?>
				<div class="message-reply">
					<h2>Reply</h2>
					<form method="post" action="<?php echo e(route('message-reply')); ?>">
						<input type="hidden" name="list_id" value="<?php echo e($listing_id); ?>" />
						<input type="hidden" name="list_user_id" value="<?php echo e($listing_user_id); ?>" />
						<input type="hidden" name="other_user_id" value="<?php echo e($other_user_id); ?>" />
						<?php if($user->id==$listing_user_id): ?>
							<input type="hidden" name="sender" value="1" />
							<input type="hidden" name="user_id" value="<?php echo e($other_user_id); ?>" />
						<?php else: ?>
							<input type="hidden" name="sender" value="2" />
							<input type="hidden" name="user_id" value="<?php echo e($listing_user_id); ?>" />
						<?php endif; ?>
						<textarea class="form-control" name="msg"></textarea>
						<input type="submit" class="btn btn-primary" value="Send Reply" />
						<?php echo e(csrf_field()); ?>

					</form>
				</div>
            </div>
            <!--/.row-box End-->
          
          </div>
        </div>
        <!--/.page-content-->
      </div>
      <!--/.row-->
    </div>
    <!--/.container-->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>