<?php $__env->startSection('content'); ?>

	<?php /*<div class="search-row-wrapper">*/ ?>
		<?php /*<div class="container ">*/ ?>

			<?php /*<form action="<?php echo e(route('search')); ?>" method="POST">*/ ?>
			<?php /*<div class="col-sm-3">*/ ?>
			<?php /*<input class="form-control keyword" placeholder="e.g. Mobile Sale" type="text" name="searchstr">*/ ?>
			<?php /*</div>*/ ?>
			<?php /*<div class="col-sm-3">*/ ?>
			<?php /*<div class="selecter  closed" tabindex="0">*/ ?>


			<?php /*<select tabindex="-1" class="form-control selecter selecter-element" name="category" id="search-category"><option value="" class="selecter-placeholder" selected="">Select An Item</option>*/ ?>
			<?php /*<option selected="selected" value="">All Categories</option>*/ ?>
			<?php /*<option value="Vehicles" style="background-color:#E9E9E9;font-weight:bold;" disabled="disabled">*/ ?>
			<?php /*- Vehicles -*/ ?>
			<?php /*</option>*/ ?>
			<?php /*<option value="Cars"> Cars</option>*/ ?>
			<?php /*<option value="Commercial vehicles"> Commercial vehicles</option>*/ ?>
			<?php /*<option value="Motorcycles"> Motorcycles</option>*/ ?>
			<?php /*<option value="Motorcycle Equipment"> Car &amp; Motorcycle Equipment</option>*/ ?>
			<?php /*<option value="Boats"> Boats</option>*/ ?>
			<?php /*<option value="Vehicles"> Other Vehicles</option>*/ ?>
			<?php /*<option value="House" style="background-color:#E9E9E9;font-weight:bold;" disabled="disabled"> -*/ ?>
			<?php /*House and Children -*/ ?>
			<?php /*</option>*/ ?>
			<?php /*<option value="Appliances"> Appliances</option>*/ ?>
			<?php /*<option value="Inside"> Inside</option>*/ ?>
			<?php /*<option value="Games"> Games and Clothing</option>*/ ?>
			<?php /*<option value="Garden"> Garden</option>*/ ?>
			<?php /*<option value="Multimedia" style="background-color:#E9E9E9;font-weight:bold;" disabled="disabled"> - Multimedia -*/ ?>
			<?php /*</option>*/ ?>
			<?php /*<option value="Telephony"> Telephony</option>*/ ?>
			<?php /*<option value="Image"> Image and sound</option>*/ ?>
			<?php /*<option value="Computers"> Computers and Accessories</option>*/ ?>
			<?php /*<option value="Video"> Video games and consoles</option>*/ ?>
			<?php /*<option value="Real" style="background-color:#E9E9E9;font-weight:bold;" disabled="disabled"> -*/ ?>
			<?php /*Real Estate -*/ ?>
			<?php /*</option>*/ ?>
			<?php /*<option value="Apartment"> Apartment</option>*/ ?>
			<?php /*<option value="Home"> Home</option>*/ ?>
			<?php /*<option value="Vacation"> Vacation Rentals</option>*/ ?>
			<?php /*<option value="Commercial"> Commercial offices and local</option>*/ ?>
			<?php /*<option value="Grounds"> Grounds</option>*/ ?>
			<?php /*<option value="Houseshares"> Houseshares</option>*/ ?>
			<?php /*<option value="Other real estate"> Other real estate</option>*/ ?>
			<?php /*<option value="Services" style="background-color:#E9E9E9;font-weight:bold;" disabled="disabled">*/ ?>
			<?php /*- Services -*/ ?>
			<?php /*</option>*/ ?>
			<?php /*<option value="Jobs"> Jobs</option>*/ ?>
			<?php /*<option value="Job application"> Job application</option>*/ ?>
			<?php /*<option value="Services"> Services</option>*/ ?>
			<?php /*<option value="Price"> Price</option>*/ ?>
			<?php /*<option value="Business"> Business and goodwill</option>*/ ?>
			<?php /*<option value="Professional"> Professional equipment</option>*/ ?>
			<?php /*<option value="dropoff" style="background-color:#E9E9E9;font-weight:bold;" disabled="disabled">*/ ?>
			<?php /*- Extra -*/ ?>
			<?php /*</option>*/ ?>
			<?php /*<option value="Other"> Other</option>*/ ?>
			<?php /*</select>*/ ?>

			<?php /*<?php echo e(Form::select('category', $subcateg, null, ['class' => 'form-control', 'placeholder' => 'All Categories'])); ?>*/ ?>


			<?php /*<span class="selecter-selected">All Categories</span><div class="selecter-options scroller"><div style="height: 100px;" class="scroller-bar"><div style="height: 100px; margin-bottom: 0px; margin-top: 0px;" class="scroller-track"><div style="" class="scroller-handle"></div></div></div><div class="scroller-content"><span class="selecter-item placeholder" data-value="">Select An Item</span><span class="selecter-item selected" data-value="">All Categories</span><span class="selecter-item disabled" data-value="Vehicles">*/ ?>
			<?php /*- Vehicles -*/ ?>
			<?php /*</span><span class="selecter-item" data-value="Cars"> Cars</span><span class="selecter-item" data-value="Commercial vehicles"> Commercial vehicles</span><span class="selecter-item" data-value="Motorcycles"> Motorcycles</span><span class="selecter-item" data-value="Motorcycle Equipment"> Car &amp; Motorcycle Equipment</span><span class="selecter-item" data-value="Boats"> Boats</span><span class="selecter-item" data-value="Vehicles"> Other Vehicles</span><span class="selecter-item disabled" data-value="House"> -*/ ?>
			<?php /*House and Children -*/ ?>
			<?php /*</span><span class="selecter-item" data-value="Appliances"> Appliances</span><span class="selecter-item" data-value="Inside"> Inside</span><span class="selecter-item" data-value="Games"> Games and Clothing</span><span class="selecter-item" data-value="Garden"> Garden</span><span class="selecter-item disabled" data-value="Multimedia"> - Multimedia -*/ ?>
			<?php /*</span><span class="selecter-item" data-value="Telephony"> Telephony</span><span class="selecter-item" data-value="Image"> Image and sound</span><span class="selecter-item" data-value="Computers"> Computers and Accessories</span><span class="selecter-item" data-value="Video"> Video games and consoles</span><span class="selecter-item disabled" data-value="Real"> -*/ ?>
			<?php /*Real Estate -*/ ?>
			<?php /*</span><span class="selecter-item" data-value="Apartment"> Apartment</span><span class="selecter-item" data-value="Home"> Home</span><span class="selecter-item" data-value="Vacation"> Vacation Rentals</span><span class="selecter-item" data-value="Commercial"> Commercial offices and local</span><span class="selecter-item" data-value="Grounds"> Grounds</span><span class="selecter-item" data-value="Houseshares"> Houseshares</span><span class="selecter-item" data-value="Other real estate"> Other real estate</span><span class="selecter-item disabled" data-value="Services">*/ ?>
			<?php /*- Services -*/ ?>
			<?php /*</span><span class="selecter-item" data-value="Jobs"> Jobs</span><span class="selecter-item" data-value="Job application"> Job application</span><span class="selecter-item" data-value="Services"> Services</span><span class="selecter-item" data-value="Price"> Price</span><span class="selecter-item" data-value="Business"> Business and goodwill</span><span class="selecter-item" data-value="Professional"> Professional equipment</span><span class="selecter-item disabled" data-value="dropoff">*/ ?>
			<?php /*- Extra -*/ ?>
			<?php /*</span><span class="selecter-item" data-value="Other"> Other</span></div></div>*/ ?>


			<?php /*</div>*/ ?>
			<?php /*</div>*/ ?>
			<?php /*<div class="col-sm-3">*/ ?>
			<?php /*<div class="selecter closed" tabindex="0">*/ ?>
			<?php /*<?php echo e(Form::select('city', $city, null, ['class' => 'form-control', 'placeholder' => 'All Locations'])); ?>*/ ?>

			<?php /*<select tabindex="-1" class="form-control selecter selecter-element" name="location" id="id-location"><option value="" class="selecter-placeholder" selected="">Select An Item</option>*/ ?>
			<?php /*<option selected="selected" value="">All Locations</option>*/ ?>
			<?php /*<option value="AL">Alabama</option>*/ ?>
			<?php /*<option value="AK">Alaska</option>*/ ?>
			<?php /*<option value="AZ">Arizona</option>*/ ?>
			<?php /*<option value="AR">Arkansas</option>*/ ?>
			<?php /*<option value="CA">California</option>*/ ?>
			<?php /*<option value="CO">Colorado</option>*/ ?>
			<?php /*<option value="CT">Connecticut</option>*/ ?>
			<?php /*<option value="DE">Delaware</option>*/ ?>
			<?php /*<option value="DC">District Of Columbia</option>*/ ?>
			<?php /*<option value="FL">Florida</option>*/ ?>
			<?php /*<option value="GA">Georgia</option>*/ ?>
			<?php /*<option value="HI">Hawaii</option>*/ ?>
			<?php /*<option value="ID">Idaho</option>*/ ?>
			<?php /*<option value="IL">Illinois</option>*/ ?>
			<?php /*<option value="IN">Indiana</option>*/ ?>
			<?php /*<option value="IA">Iowa</option>*/ ?>
			<?php /*<option value="KS">Kansas</option>*/ ?>
			<?php /*<option value="KY">Kentucky</option>*/ ?>
			<?php /*<option value="LA">Louisiana</option>*/ ?>
			<?php /*<option value="ME">Maine</option>*/ ?>
			<?php /*<option value="MD">Maryland</option>*/ ?>
			<?php /*<option value="MA">Massachusetts</option>*/ ?>
			<?php /*<option value="MI">Michigan</option>*/ ?>
			<?php /*<option value="MN">Minnesota</option>*/ ?>
			<?php /*<option value="MS">Mississippi</option>*/ ?>
			<?php /*<option value="MO">Missouri</option>*/ ?>
			<?php /*<option value="MT">Montana</option>*/ ?>
			<?php /*<option value="NE">Nebraska</option>*/ ?>
			<?php /*<option value="NV">Nevada</option>*/ ?>
			<?php /*<option value="NH">New Hampshire</option>*/ ?>
			<?php /*<option value="NJ">New Jersey</option>*/ ?>
			<?php /*<option value="NM">New Mexico</option>*/ ?>
			<?php /*<option value="NY">New York</option>*/ ?>
			<?php /*<option value="NC">North Carolina</option>*/ ?>
			<?php /*<option value="ND">North Dakota</option>*/ ?>
			<?php /*<option value="OH">Ohio</option>*/ ?>
			<?php /*<option value="OK">Oklahoma</option>*/ ?>
			<?php /*<option value="OR">Oregon</option>*/ ?>
			<?php /*<option value="PA">Pennsylvania</option>*/ ?>
			<?php /*<option value="RI">Rhode Island</option>*/ ?>
			<?php /*<option value="SC">South Carolina</option>*/ ?>
			<?php /*<option value="SD">South Dakota</option>*/ ?>
			<?php /*<option value="TN">Tennessee</option>*/ ?>
			<?php /*<option value="TX">Texas</option>*/ ?>
			<?php /*<option value="UT">Utah</option>*/ ?>
			<?php /*<option value="VT">Vermont</option>*/ ?>
			<?php /*<option value="VA">Virginia</option>*/ ?>
			<?php /*<option value="WA">Washington</option>*/ ?>
			<?php /*<option value="WV">West Virginia</option>*/ ?>
			<?php /*<option value="WI">Wisconsin</option>*/ ?>
			<?php /*<option value="WY">Wyoming</option>*/ ?>
			<?php /*<option value="Other-Locations">Other Locations</option>*/ ?>
			<?php /*</select> */ ?>
			<?php /*<span class="selecter-selected">All Locations</span><div class="selecter-options scroller"><div style="height: 100px;" class="scroller-bar"><div style="height: 100px; margin-bottom: 0px; margin-top: 0px;" class="scroller-track"><div style="" class="scroller-handle"></div></div></div><div class="scroller-content"><span class="selecter-item placeholder" data-value="">Select An Item</span><span class="selecter-item selected" data-value="">All Locations</span><span class="selecter-item" data-value="AL">Alabama</span><span class="selecter-item" data-value="AK">Alaska</span><span class="selecter-item" data-value="AZ">Arizona</span><span class="selecter-item" data-value="AR">Arkansas</span><span class="selecter-item" data-value="CA">California</span><span class="selecter-item" data-value="CO">Colorado</span><span class="selecter-item" data-value="CT">Connecticut</span><span class="selecter-item" data-value="DE">Delaware</span><span class="selecter-item" data-value="DC">District Of Columbia</span><span class="selecter-item" data-value="FL">Florida</span><span class="selecter-item" data-value="GA">Georgia</span><span class="selecter-item" data-value="HI">Hawaii</span><span class="selecter-item" data-value="ID">Idaho</span><span class="selecter-item" data-value="IL">Illinois</span><span class="selecter-item" data-value="IN">Indiana</span><span class="selecter-item" data-value="IA">Iowa</span><span class="selecter-item" data-value="KS">Kansas</span><span class="selecter-item" data-value="KY">Kentucky</span><span class="selecter-item" data-value="LA">Louisiana</span><span class="selecter-item" data-value="ME">Maine</span><span class="selecter-item" data-value="MD">Maryland</span><span class="selecter-item" data-value="MA">Massachusetts</span><span class="selecter-item" data-value="MI">Michigan</span><span class="selecter-item" data-value="MN">Minnesota</span><span class="selecter-item" data-value="MS">Mississippi</span><span class="selecter-item" data-value="MO">Missouri</span><span class="selecter-item" data-value="MT">Montana</span><span class="selecter-item" data-value="NE">Nebraska</span><span class="selecter-item" data-value="NV">Nevada</span><span class="selecter-item" data-value="NH">New Hampshire</span><span class="selecter-item" data-value="NJ">New Jersey</span><span class="selecter-item" data-value="NM">New Mexico</span><span class="selecter-item" data-value="NY">New York</span><span class="selecter-item" data-value="NC">North Carolina</span><span class="selecter-item" data-value="ND">North Dakota</span><span class="selecter-item" data-value="OH">Ohio</span><span class="selecter-item" data-value="OK">Oklahoma</span><span class="selecter-item" data-value="OR">Oregon</span><span class="selecter-item" data-value="PA">Pennsylvania</span><span class="selecter-item" data-value="RI">Rhode Island</span><span class="selecter-item" data-value="SC">South Carolina</span><span class="selecter-item" data-value="SD">South Dakota</span><span class="selecter-item" data-value="TN">Tennessee</span><span class="selecter-item" data-value="TX">Texas</span><span class="selecter-item" data-value="UT">Utah</span><span class="selecter-item" data-value="VT">Vermont</span><span class="selecter-item" data-value="VA">Virginia</span><span class="selecter-item" data-value="WA">Washington</span><span class="selecter-item" data-value="WV">West Virginia</span><span class="selecter-item" data-value="WI">Wisconsin</span><span class="selecter-item" data-value="WY">Wyoming</span><span class="selecter-item" data-value="Other-Locations">Other Locations</span></div></div>*/ ?>

			<?php /*</div>*/ ?>
			<?php /*</div>*/ ?>
			<?php /*<div class="col-sm-3">*/ ?>
			<?php /*<button class="btn btn-block btn-primary  "><i class="fa fa-search"></i></button>*/ ?>
			<?php /*<?php echo e(csrf_field()); ?>*/ ?>
			<?php /*</div>*/ ?>
			<?php /*</form>*/ ?>
		<?php /*</div>*/ ?>
	<?php /*</div>*/ ?>
	<!-- /.search-row -->
	<div class="main-container">
		<div class="container">
			<div class="row">
				<!-- this (.mobile-filter-sidebar) part will be position fixed in mobile version -->
				<div class="col-sm-3 page-sidebar mobile-filter-sidebar">
					<aside>
						<div class="inner-box">
							<div class="categories-list  list-filter">

								<?php /*<h3>Filters:</h3>*/ ?>
								<?php /*<form method="post" action="<?php echo e(route('search')); ?>">*/ ?>


									<?php /*<label>Search: </label> <input type="text" name="searchstr" class="form-control" value="<?php echo e(isset($searchdata['searchstr']) ? $searchdata['searchstr'] : ''); ?>"/>*/ ?>

									<?php /*<label>Category: </label>*/ ?>
									<?php /*<?php echo e(Form::select('category', $subcateg, $searchdata['categoryid'], ['class' => 'form-control', 'placeholder' => 'All Categories', 'id' => 'category'])); ?>*/ ?>

									<?php /*<label>Location: </label>*/ ?>
									<?php /*<?php echo e(Form::select('city', $city, $searchdata['cityid'], ['class' => 'form-control js-locations', 'placeholder' => 'All Locations', 'id' => 'location'])); ?>*/ ?>

									<?php /*<label>Price: </label> <input type="text" class="form-control price" maxlength="6" name="price1" value="<?php echo e($searchdata['price1']); ?>"/> - <input type="text" class="form-control price" maxlength="6" name="price2"*/ ?>
											<?php /*value="<?php echo e($searchdata['price2']); ?>"/>*/ ?>


									<?php /*<?php if($subCategory): ?>*/ ?>

										<?php /*<?php if($subCategory->data1 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data1); ?></label>*/ ?>
											<?php /*<?php if($subCategory->details1 == ""): ?>*/ ?>
												<?php /*<input type="text" class="form-control" name="data1"/>*/ ?>
											<?php /*<?php else: ?>*/ ?>
												<?php /*<?php echo e(Form::select('data1', $subCategory->getDetails(1), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
											<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
										<?php /*<?php if($subCategory->data2 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data2); ?></label>*/ ?>
											<?php /*<?php if($subCategory->details2 == ""): ?>*/ ?>
												<?php /*<input type="text" class="form-control" name="data2"/>*/ ?>
											<?php /*<?php else: ?>*/ ?>
												<?php /*<?php echo e(Form::select('data2', $subCategory->getDetails(2), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
											<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
										<?php /*<?php if($subCategory->data3 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data3); ?></label>*/ ?>
											<?php /*<?php if($subCategory->details3 == ""): ?>*/ ?>
												<?php /*<input type="text" class="form-control" name="data3"/>*/ ?>
											<?php /*<?php else: ?>*/ ?>
												<?php /*<?php echo e(Form::select('data3', $subCategory->getDetails(3), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
											<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
										<?php /*<?php if($subCategory->data4 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data4); ?></label>*/ ?>
												<?php /*<?php if($subCategory->details4 == ""): ?>*/ ?>
													<?php /*<input type="text" class="form-control" name="data4"/>*/ ?>
												<?php /*<?php else: ?>*/ ?>
													<?php /*<?php echo e(Form::select('data4', $subCategory->getDetails(4), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
												<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
										<?php /*<?php if($subCategory->data5 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data5); ?></label> <?php if($subCategory->details5 == ""): ?>*/ ?>
													<?php /*<input type="text" class="form-control" name="data5"/>*/ ?>
												<?php /*<?php else: ?>*/ ?>
													<?php /*<?php echo e(Form::select('data5', $subCategory->getDetails(5), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
												<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
										<?php /*<?php if($subCategory->data6 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data6); ?></label> <?php if($subCategory->details6 == ""): ?>*/ ?>
													<?php /*<input type="text" class="form-control" name="data6"/>*/ ?>
												<?php /*<?php else: ?>*/ ?>
													<?php /*<?php echo e(Form::select('data6', $subCategory->getDetails(6), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
												<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
										<?php /*<?php if($subCategory->data7 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data7); ?></label> <?php if($subCategory->details7 == ""): ?>*/ ?>
													<?php /*<input type="text" class="form-control" name="data7"/>*/ ?>
												<?php /*<?php else: ?>*/ ?>
													<?php /*<?php echo e(Form::select('data7', $subCategory->getDetails(7), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
												<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
										<?php /*<?php if($subCategory->data8 != ""): ?>*/ ?>

											<?php /*<label><?php echo e($subCategory->data8); ?></label> <?php if($subCategory->details8 == ""): ?>*/ ?>
													<?php /*<input type="text" class="form-control" name="data8"/>*/ ?>
												<?php /*<?php else: ?>*/ ?>
													<?php /*<?php echo e(Form::select('data8', $subCategory->getDetails(8), null, ['class' => 'form-control', 'placeholder' => ''])); ?>*/ ?>
												<?php /*<?php endif; ?>*/ ?>

										<?php /*<?php endif; ?>*/ ?>
									<?php /*<?php endif; ?>*/ ?>
									<?php /*<label>&nbsp;</label><br/> <input type="submit" class="btn btn-primary" name="submit" value="Search"/>*/ ?>
									<?php /*<?php echo e(csrf_field()); ?>*/ ?>

								<?php /*</form>*/ ?>


								<?php /*<h5 class="list-title"><strong><a href="#">All Categories</a></strong></h5>*/ ?>
								<?php /*<ul class=" list-unstyled">*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Electronics</span><span*/ ?>
								<?php /*class="count">&nbsp;8626</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Automobiles </span><span*/ ?>
								<?php /*class="count">&nbsp;123</span></a></li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Property </span><span class="count">&nbsp;742</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Services </span><span class="count">&nbsp;8525</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">For Sale </span><span class="count">&nbsp;357</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Learning </span><span class="count">&nbsp;3576</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Jobs </span><span class="count">&nbsp;453</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Cars &amp; Vehicles</span><span*/ ?>
								<?php /*class="count">&nbsp;801</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*<li><a href="sub-category-sub-location.html"><span class="title">Other</span><span class="count">&nbsp;9803</span></a>*/ ?>
								<?php /*</li>*/ ?>
								<?php /*</ul>*/ ?>
							</div>
							<!--/.categories-list-->

						<?php /*<div class="locations-list  list-filter">*/ ?>
						<?php /*<h5 class="list-title"><strong><a href="#">Location</a></strong></h5>*/ ?>
						<?php /*<ul class="browse-list list-unstyled long-list">*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"> Atlanta </a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"> Wichita </a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"> Anchorage </a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"> Dallas </a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html">New York </a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"> Santa Ana/Anaheim </a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"> Miami </a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"> Virginia Beach </a></li>*/ ?>
						<?php /*<li class="maxlist-hidden" style="display: none;"><a href="sub-category-sub-location.html"> San Diego </a></li>*/ ?>
						<?php /*<li class="maxlist-hidden" style="display: none;"><a href="sub-category-sub-location.html"> Boston </a></li>*/ ?>
						<?php /*<li class="maxlist-hidden" style="display: none;"><a href="sub-category-sub-location.html"> Houston </a></li>*/ ?>
						<?php /*<li class="maxlist-hidden" style="display: none;"><a href="sub-category-sub-location.html">Salt Lake City </a></li>*/ ?>
						<?php /*<li class="maxlist-hidden" style="display: none;"><a href="sub-category-sub-location.html"> Other Locations </a></li>*/ ?>
						<?php /*</ul>*/ ?>
						<?php /*<p class="maxlist-more"><a href="#">View More (5)</a></p>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.locations-list-->*/ ?>

						<?php /*<div class="locations-list  list-filter">*/ ?>
						<?php /*<h5 class="list-title"><strong><a href="#">Price range</a></strong></h5>*/ ?>

						<?php /*<form role="form" class="form-inline ">*/ ?>
						<?php /*<div class="form-group col-sm-4 no-padding">*/ ?>
						<?php /*<input placeholder="$ 2000 " id="minPrice" class="form-control" type="text">*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<div class="form-group col-sm-1 no-padding text-center hidden-xs"> -</div>*/ ?>
						<?php /*<div class="form-group col-sm-4 no-padding">*/ ?>
						<?php /*<input placeholder="$ 3000 " id="maxPrice" class="form-control" type="text">*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<div class="form-group col-sm-3 no-padding">*/ ?>
						<?php /*<button class="btn btn-default pull-right btn-block-xs" type="submit">GO*/ ?>
						<?php /*</button>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*</form>*/ ?>
						<?php /*<div style="clear:both"></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.list-filter-->*/ ?>
						<?php /*<div class="locations-list  list-filter">*/ ?>
						<?php /*<h5 class="list-title"><strong><a href="#">Seller</a></strong></h5>*/ ?>
						<?php /*<ul class="browse-list list-unstyled long-list">*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html"><strong>All Ads</strong> <span*/ ?>
						<?php /*class="count">228,705</span></a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html">Business <span class="count">28,705</span></a></li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html">Personal <span class="count">18,705</span></a></li>*/ ?>
						<?php /*</ul>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.list-filter-->*/ ?>
						<?php /*<div class="locations-list  list-filter">*/ ?>
						<?php /*<h5 class="list-title"><strong><a href="#">Condition</a></strong></h5>*/ ?>
						<?php /*<ul class="browse-list list-unstyled long-list">*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html">New <span class="count">228,705</span></a>*/ ?>
						<?php /*</li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html">Used <span class="count">28,705</span></a>*/ ?>
						<?php /*</li>*/ ?>
						<?php /*<li><a href="sub-category-sub-location.html">None </a></li>*/ ?>
						<?php /*</ul>*/ ?>
						<?php /*</div>*/ ?>
						<!--/.list-filter-->
							<div style="clear:both"></div>
						</div>

						<!--/.categories-list-->
					</aside>
				</div>
				<!--/.page-side-bar-->
				<div class="col-sm-9 page-content col-thin-left">

					<div class="category-list inner-box">

					<h3>Filters:</h3>
					<div class="row">
						<form method="post" action="<?php echo e(route('search')); ?>">
						<div class="col-md-4">
							<label>Search: </label> <input type="text" name="searchstr" class="form-control" value="<?php echo e(isset($searchdata['searchstr']) ? $searchdata['searchstr'] : ''); ?>"/>
						</div>
						<div class="col-md-4">
							<label>Category: </label>

							<div class="combo-outer" id="combo-box-outer"></div>

							<?php /*<?php echo e(Form::select('category', $subcateg, $searchdata['categoryid'], ['class' => 'form-control', 'placeholder' => 'All Categories', 'id' => 'category'])); ?>*/ ?>
						</div>
						<div class="col-md-4">
							<label>Location: </label>
							<?php echo e(Form::select('city', $city, $searchdata['cityid'], ['class' => 'form-control js-locations', 'placeholder' => 'All Locations', 'id' => 'location'])); ?>

						</div>
						<div class="col-md-4">
							<label>Price: </label><br /> <input type="text" class="form-control price" maxlength="6" name="price1" value="<?php echo e($searchdata['price1']); ?>"/> - <input type="text" class="form-control price" maxlength="6" name="price2" value="<?php echo e($searchdata['price2']); ?>"/>
						</div>

						<?php if($subCategory): ?>

							<?php if($subCategory->data1 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data1); ?></label>
								<?php if($subCategory->details1 == ""): ?>
									<input type="text" class="form-control" name="data1"/>
								<?php else: ?>
									<?php echo e(Form::select('data1', $subCategory->getDetails(1), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
										</div>

							<?php endif; ?>
							<?php if($subCategory->data2 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data2); ?></label>
								<?php if($subCategory->details2 == ""): ?>
									<input type="text" class="form-control" name="data2"/>
								<?php else: ?>
									<?php echo e(Form::select('data2', $subCategory->getDetails(2), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
										</div>

							<?php endif; ?>
							<?php if($subCategory->data3 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data3); ?></label>
								<?php if($subCategory->details3 == ""): ?>
									<input type="text" class="form-control" name="data3"/>
								<?php else: ?>
									<?php echo e(Form::select('data3', $subCategory->getDetails(3), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
										</div>

							<?php endif; ?>
							<?php if($subCategory->data4 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data4); ?></label>
								<?php if($subCategory->details4 == ""): ?>
									<input type="text" class="form-control" name="data4"/>
								<?php else: ?>
									<?php echo e(Form::select('data4', $subCategory->getDetails(4), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
										</div>

							<?php endif; ?>
							<?php if($subCategory->data5 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data5); ?></label> <?php if($subCategory->details5 == ""): ?>
									<input type="text" class="form-control" name="data5"/>
								<?php else: ?>
									<?php echo e(Form::select('data5', $subCategory->getDetails(5), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
										</div>

							<?php endif; ?>
							<?php if($subCategory->data6 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data6); ?></label> <?php if($subCategory->details6 == ""): ?>
									<input type="text" class="form-control" name="data6"/>
								<?php else: ?>
									<?php echo e(Form::select('data6', $subCategory->getDetails(6), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
</div>
							<?php endif; ?>
							<?php if($subCategory->data7 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data7); ?></label> <?php if($subCategory->details7 == ""): ?>
									<input type="text" class="form-control" name="data7"/>
								<?php else: ?>
									<?php echo e(Form::select('data7', $subCategory->getDetails(7), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
										</div>

							<?php endif; ?>
							<?php if($subCategory->data8 != ""): ?>
									<div class="col-md-4">
								<label><?php echo e($subCategory->data8); ?></label> <?php if($subCategory->details8 == ""): ?>
									<input type="text" class="form-control" name="data8"/>
								<?php else: ?>
									<?php echo e(Form::select('data8', $subCategory->getDetails(8), null, ['class' => 'form-control', 'placeholder' => ''])); ?>

								<?php endif; ?>
</div>
							<?php endif; ?>
						<?php endif; ?>
							<div class="col-md-4">
						<label>&nbsp;</label><br/> <input type="submit" class="btn btn-primary" name="submit" value="Search"/>
						<?php echo e(csrf_field()); ?></div>

						</form>

					</div>

					<?php /*<div class="sub-category-filters row">*/ ?>
					<?php /*<form method="post" action="<?php echo e(route('search')); ?>">*/ ?>
					<?php /*<?php if($subCategory->data1 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data1); ?></label> <input type="text" class="form-control" name="data1"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<?php if($subCategory->data2 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data2); ?></label> <input type="text" class="form-control" name="data2"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<?php if($subCategory->data3 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data3); ?></label> <input type="text" class="form-control" name="data3"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<?php if($subCategory->data4 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data4); ?></label> <input type="text" class="form-control" name="data4"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<?php if($subCategory->data5 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data5); ?></label> <input type="text" class="form-control" name="data5"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<?php if($subCategory->data6 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data6); ?></label> <input type="text" class="form-control" name="data6"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<?php if($subCategory->data7 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data7); ?></label> <input type="text" class="form-control" name="data7"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<?php if($subCategory->data8 != ""): ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label><?php echo e($subCategory->data8); ?></label> <input type="text" class="form-control" name="data8"/>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<?php endif; ?>*/ ?>
					<?php /*<div class="col-sm-4">*/ ?>
					<?php /*<label>&nbsp;</label><br/> <input type="submit" class="btn btn-primary" name="submit" value="Search"/>*/ ?>
					<?php /*<?php echo e(csrf_field()); ?>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*</form>*/ ?>
					<?php /*</div>*/ ?>
					</div>

					<div class="tab-box ">

						<!-- Nav tabs -->
						<ul class="nav nav-tabs add-tabs" role="tablist">
							<li class="active"><a href="#allAds" role="tab" data-toggle="tab">All Ads <span
											class="badge"><?php echo e($listings->total()); ?></span></a></li>
						</ul>
						<div class="tab-filter">
							<div class="selecter select-short-by closed" tabindex="0"><select tabindex="-1" class="selectpicker selecter-element" data-style="btn-select" data-width="auto">
									<option value="Short by">Sort by</option>
									<option value="Price: Low to High">Price: Low to High</option>
									<option value="Price: High to Low">Price: High to Low</option>
								</select><span class="selecter-selected">Sort by</span>
								<div class="selecter-options scroller">
									<div style="height: 100px;" class="scroller-bar">
										<div style="height: 100px; margin-bottom: 0px; margin-top: 0px;" class="scroller-track">
											<div style="" class="scroller-handle"></div>
										</div>
									</div>
									<div class="scroller-content"><span class="selecter-item selected" data-value="Short by">Sort by</span><span class="selecter-item"
												data-value="Price: Low to High">Price: Low to High</span><span
												class="selecter-item" data-value="Price: High to Low">Price: High to Low</span></div>
								</div>
							</div>
						</div>
					</div>
					<!--/.tab-box-->

					<div class="listing-filter">
						<div class="pull-left col-xs-6">
							<?php /*<div class="breadcrumb-list"><a href="#" class="current"> <span>All ads</span></a> in*/ ?>
							<?php /*<!-- cityName will replace with selected location/area from location modal -->*/ ?>
							<?php /*<span class="cityName"> New York </span> <a href="#selectRegion" id="dropdownMenu1" data-toggle="modal">*/ ?>
							<?php /*<span class="caret"></span> </a></div>*/ ?>
						</div>
						<div class="pull-right col-xs-6 text-right listing-view-action"><span class="list-view active"><i
										class="  icon-th"></i></span> <span class="compact-view"><i class=" icon-th-list  "></i></span> <span class="grid-view "><i class=" icon-th-large "></i></span></div>
						<div style="clear:both"></div>
					</div>
					<!--/.listing-filter-->

					<!-- Mobile Filter bar-->
					<div class="mobile-filter-bar col-lg-12  ">
						<ul class="list-unstyled list-inline no-margin no-padding">
							<li class="filter-toggle">
								<a class=""> <i class="  icon-th-list"></i> Filters </a>
							</li>
							<li>


								<div class="dropdown">
									<a data-toggle="dropdown" class="dropdown-toggle"><i class="caret "></i> Sort by </a>
									<ul class="dropdown-menu">
										<li><a href="" rel="nofollow">Relevance</a></li>
										<li><a href="" rel="nofollow">Date</a></li>
										<li><a href="" rel="nofollow">Company</a></li>
									</ul>
								</div>

							</li>
						</ul>
					</div>
					<div class="menu-overly-mask"></div>
					<!-- Mobile Filter bar End-->


					<div class="adds-wrapper">
						<?php foreach($listings as $row): ?>
							<div class="item-list">


								<div class="col-sm-2 no-padding photobox">

									<?php if (isset($row->photo->first()->photo)) {
										$p = 'uploads/ads/' . $row->photo->first()->photo;
									} else {
										$p = 'src/images/product-thumb-default.jpg';
									} ?>

									<div class="add-image"><span class="photo-count"><i class="fa fa-camera"></i> <?php echo e($row->photo->count()); ?> </span><a href="<?php echo e(route('ad', [$row->id, $row->title])); ?>"><img alt="img" src="<?php echo e(URL::to($p)); ?>"
													class="thumbnail no-margin img-responsive"> </a>
									</div>
								</div>
								<!--/.photobox-->

								<div class="col-sm-7 add-desc-box">
									<div class="add-details">
										<h5 class="add-title"><a href="<?php echo e(route('ad', [$row->id, $row->title])); ?>">
												<?php echo e($row->title); ?> </a></h5>

										<?php

										// return 1 if true
										// dump($user); echo $user->id;
										if ($user != null) {
											$isFavorite = isset($row->favorite()->where('user_id', $user->id)->first()->user_id);
										} else {
											$isFavorite = false;
										}

										?>


										<span class="info-row"> <span data-original-title="Business Ads" class="add-type business-ads tooltipHere" data-toggle="tooltip" data-placement="right" title="">B </span> <span class="date"><i
														class=" icon-clock"> </i> <?php echo e(date('M d, Y H:i', strtotime($row->created_at))); ?> </span> - <span class="category"><?php echo e($row->subcategory->sub_category); ?> </span>- <span class="item-location"><i
														class="fa fa-map-marker"></i> <?php echo e($row->city->city); ?> </span> </span>
									</div>
								</div>


								<!--/.add-desc-box-->
								<div id="row-<?php echo e($row->id); ?>" class="col-sm-3 text-right price-box">
									<h2 class="item-price"> JD <?php echo e($row->price); ?> </h2>
									<?php /*<a class="btn btn-danger  btn-sm make-favorite"> <i class="fa fa-certificate"></i> <span>Top Ads</span> </a>*/ ?>

									<button data-link="<?php echo e($row->id); ?>" class="btn btn-danger btn-sm mark-favorite" <?php if($isFavorite): ?> style="display:none;" <?php endif; ?>><i class="fa fa-heart"></i> <span> Favorite </span></button>
									<button data-link="<?php echo e($row->id); ?>" class="btn btn-default btn-sm unmark-favorite" <?php if(!$isFavorite): ?> style="display:none;" <?php endif; ?>><i class="fa fa-heart-o"></i> <span> Remove</span></button>
								</div>
								<!--/.add-desc-box-->
							</div>
							<!--/.item-list-->
						<?php endforeach; ?>
						<?php /**/ ?>
						<?php /*<div class="item-list">*/ ?>
						<?php /*<div class="cornerRibbons featuredAds">*/ ?>
						<?php /*<a href="#"> Featured Ads</a>*/ ?>
						<?php /*</div>*/ ?>
						<?php /**/ ?>
						<?php /*<div class="col-sm-2 no-padding photobox">*/ ?>
						<?php /*<div class="add-image"><span class="photo-count"><i class="fa fa-camera"></i> 2 </span> <a*/ ?>
						<?php /*href="ads-details.html"><img class="thumbnail no-margin" src="images/item/tp/Image00008.jpg"*/ ?>
						<?php /*alt="img"></a></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.photobox-->*/ ?>
						<?php /*<div class="col-sm-7 add-desc-box">*/ ?>
						<?php /*<div class="add-details">*/ ?>
						<?php /*<h5 class="add-title"><a href="ads-details.html">*/ ?>
						<?php /*Sony Xperia dual sim 100% brand new </a></h5>*/ ?>
						<?php /*<span class="info-row"> <span data-original-title="Business Ads"*/ ?>
						<?php /*class="add-type business-ads tooltipHere" data-toggle="tooltip"*/ ?>
						<?php /*data-placement="right" title="">B </span> <span class="date"><i*/ ?>
						<?php /*class=" icon-clock"> </i> Today 1:21 pm </span> - <span class="category">Electronics </span>- <span*/ ?>
						<?php /*class="item-location"><i class="fa fa-map-marker"></i> New York </span> </span></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*<div class="col-sm-3 text-right  price-box">*/ ?>
						<?php /*<h2 class="item-price"> $ 250 </h2>*/ ?>
						<?php /*<a class="btn btn-danger  btn-sm make-favorite"> <i class="fa fa-certificate"></i>*/ ?>
						<?php /*<span>Featured Ads</span> </a> <a class="btn btn-default  btn-sm make-favorite">*/ ?>
						<?php /*<i class="fa fa-heart"></i> <span>Save</span> </a></div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*</div>*/ ?>
						<?php /**/ ?>
						<?php /*<div class="item-list">*/ ?>
						<?php /*<div class="cornerRibbons urgentAds">*/ ?>
						<?php /*<a href="#"> Urgent</a>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<div class="col-sm-2 no-padding photobox">*/ ?>
						<?php /*<div class="add-image"><span class="photo-count"><i class="fa fa-camera"></i> 2 </span> <a*/ ?>
						<?php /*href="ads-details.html"><img class="thumbnail no-margin"*/ ?>
						<?php /*src="images/item/FreeGreatPicture.com-46404-google-drops-nexus-4-by-100-offers-15-day-price-protection-refund.jpg"*/ ?>
						<?php /*alt="img"></a></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.photobox-->*/ ?>
						<?php /*<div class="col-sm-7 add-desc-box">*/ ?>
						<?php /*<div class="add-details">*/ ?>
						<?php /*<h5 class="add-title"><a href="ads-details.html"> Google drops Nexus 4 </a></h5>*/ ?>
						<?php /*<span class="info-row"> <span data-original-title="Business Ads"*/ ?>
						<?php /*class="add-type business-ads tooltipHere" data-toggle="tooltip"*/ ?>
						<?php /*data-placement="right" title="">B </span> <span class="date"><i*/ ?>
						<?php /*class=" icon-clock"> </i> Today 1:21 pm </span> - <span class="category">Electronics </span>- <span*/ ?>
						<?php /*class="item-location"><i class="fa fa-map-marker"></i> New York </span> </span></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*<div class="col-sm-3 text-right  price-box">*/ ?>
						<?php /*<h2 class="item-price"> $ 150 </h2>*/ ?>
						<?php /*<a class="btn btn-danger  btn-sm make-favorite"> <i class="fa fa-certificate"></i>*/ ?>
						<?php /*<span>Urgent</span> </a>*/ ?>
						<?php /*<a class="btn btn-default  btn-sm make-favorite"> <i class="fa fa-heart"></i> <span>Save</span>*/ ?>
						<?php /*</a></div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.item-list-->*/ ?>
						<?php /**/ ?>
						<?php /*<!--/.item-list-->*/ ?>
						<?php /*<div class="item-list">*/ ?>
						<?php /**/ ?>
						<?php /*<div class="col-sm-2 no-padding photobox">*/ ?>
						<?php /*<div class="add-image"><span class="photo-count"><i class="fa fa-camera"></i> 2 </span> <a*/ ?>
						<?php /*href="ads-details.html"><img class="thumbnail no-margin" src="images/item/tp/Image00014.jpg"*/ ?>
						<?php /*alt="img"></a></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.photobox-->*/ ?>
						<?php /*<div class="col-sm-7 add-desc-box">*/ ?>
						<?php /*<div class="add-details">*/ ?>
						<?php /*<h5 class="add-title"><a href="ads-details.html"> Samsung Galaxy S Dous (Brand*/ ?>
						<?php /*New/ Intact Box) With 1year Warranty </a></h5>*/ ?>
						<?php /*<span class="info-row"> <span data-original-title="Business Ads"*/ ?>
						<?php /*class="add-type business-ads tooltipHere" data-toggle="tooltip"*/ ?>
						<?php /*data-placement="right" title="">B </span> <span class="date"><i*/ ?>
						<?php /*class=" icon-clock"> </i> Today 1:21 pm </span> - <span class="category">Electronics </span>- <span*/ ?>
						<?php /*class="item-location"><i class="fa fa-map-marker"></i> New York </span> </span></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*<div class="col-sm-3 text-right  price-box">*/ ?>
						<?php /*<h2 class="item-price"> $ 230</h2>*/ ?>
						<?php /*<a class="btn btn-default  btn-sm make-favorite"> <i class="fa fa-heart"></i> <span>Save</span>*/ ?>
						<?php /*</a></div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.item-list-->*/ ?>
						<?php /*<div class="item-list">*/ ?>
						<?php /*<div class="col-sm-2 no-padding photobox">*/ ?>
						<?php /*<div class="add-image"><span class="photo-count"><i class="fa fa-camera"></i> 2 </span> <a*/ ?>
						<?php /*href="ads-details.html"><img class="thumbnail no-margin" src="images/item/tp/Image00003.jpg"*/ ?>
						<?php /*alt="img"></a></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.photobox-->*/ ?>
						<?php /*<div class="col-sm-7 add-desc-box">*/ ?>
						<?php /*<div class="add-details">*/ ?>
						<?php /*<h5 class="add-title"><a href="ads-details.html"> MSI GE70 Apache Pro-061 17.3"*/ ?>
						<?php /*Core i5-4200H/8GB DDR3/NV GTX860M Gaming Laptop </a></h5>*/ ?>
						<?php /*<span class="info-row"> <span data-original-title="Business Ads"*/ ?>
						<?php /*class="add-type business-ads tooltipHere" data-toggle="tooltip"*/ ?>
						<?php /*data-placement="right" title="">B </span> <span class="date"><i*/ ?>
						<?php /*class=" icon-clock"> </i> Today 1:21 pm </span> - <span class="category">Electronics </span>- <span*/ ?>
						<?php /*class="item-location"><i class="fa fa-map-marker"></i> New York </span> </span></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*<div class="col-sm-3 text-right  price-box">*/ ?>
						<?php /*<h2 class="item-price"> $ 400 </h2>*/ ?>
						<?php /*<a class="btn btn-default  btn-sm make-favorite"> <i class="fa fa-heart"></i> <span>Save</span>*/ ?>
						<?php /*</a></div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.item-list-->*/ ?>
						<?php /*<div class="item-list">*/ ?>
						<?php /*<div class="col-sm-2 no-padding photobox">*/ ?>
						<?php /*<div class="add-image"><span class="photo-count"><i class="fa fa-camera"></i> 2 </span> <a*/ ?>
						<?php /*href="ads-details.html"><img class="thumbnail no-margin" src="images/item/tp/Image00022.jpg"*/ ?>
						<?php /*alt="img"></a></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.photobox-->*/ ?>
						<?php /*<div class="col-sm-7 add-desc-box">*/ ?>
						<?php /*<div class="add-details">*/ ?>
						<?php /*<h5 class="add-title"><a href="ads-details.html"> Apple iPod touch 16 GB 3rd*/ ?>
						<?php /*Generation </a></h5>*/ ?>
						<?php /*<span class="info-row"> <span data-original-title="Business Ads"*/ ?>
						<?php /*class="add-type business-ads tooltipHere" data-toggle="tooltip"*/ ?>
						<?php /*data-placement="right" title="">B </span> <span class="date"><i*/ ?>
						<?php /*class=" icon-clock"> </i> Today 1:21 pm </span> - <span class="category">Electronics </span>- <span*/ ?>
						<?php /*class="item-location"><i class="fa fa-map-marker"></i> New York </span> </span></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*<div class="col-sm-3 text-right  price-box">*/ ?>
						<?php /*<h2 class="item-price"> $ 150 </h2>*/ ?>
						<?php /*<a class="btn btn-default  btn-sm make-favorite"> <i class="fa fa-heart"></i> <span>Save</span>*/ ?>
						<?php /*</a></div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.item-list-->*/ ?>
						<?php /*<div class="item-list">*/ ?>
						<?php /*<div class="col-sm-2 no-padding photobox">*/ ?>
						<?php /*<div class="add-image"><span class="photo-count"><i class="fa fa-camera"></i> 2 </span> <a*/ ?>
						<?php /*href="ads-details.html"><img class="thumbnail no-margin"*/ ?>
						<?php /*src="images/item/FreeGreatPicture.com-46405-google-drops-price-of-nexus-4-smartphone.jpg"*/ ?>
						<?php /*alt="img"></a></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.photobox-->*/ ?>
						<?php /*<div class="col-sm-7 add-desc-box">*/ ?>
						<?php /*<div class="add-details">*/ ?>
						<?php /*<h5 class="add-title"><a href="ads-details.html"> Google drops Nexus 4 by $100,*/ ?>
						<?php /*offers 15 day price protection refund </a></h5>*/ ?>
						<?php /*<span class="info-row"> <span data-original-title="Business Ads"*/ ?>
						<?php /*class="add-type business-ads tooltipHere" data-toggle="tooltip"*/ ?>
						<?php /*data-placement="right" title="">B </span> <span class="date"><i*/ ?>
						<?php /*class=" icon-clock"> </i> Today 1:21 pm </span> - <span class="category">Electronics </span>- <span*/ ?>
						<?php /*class="item-location"><i class="fa fa-map-marker"></i> New York </span> </span></div>*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*<div class="col-sm-3 text-right  price-box">*/ ?>
						<?php /*<h2 class="item-price"> $ 150 </h2>*/ ?>
						<?php /*<a class="btn btn-default  btn-sm make-favorite"> <i class="fa fa-heart"></i> <span>Save</span>*/ ?>
						<?php /*</a></div>*/ ?>
						<?php /*<!--/.add-desc-box-->*/ ?>
						<?php /*</div>*/ ?>
						<?php /*<!--/.item-list-->*/ ?>


					</div>
					<!--/.adds-wrapper-->
					<div class="text-center"><?php echo e($listings->appends([
						'searchstr' => $searchdata['searchstr'],
						'category' => $searchdata['categoryid'],
						'city' => $searchdata['cityid'],
						'price1' => $searchdata['price1'],
						'price2' => $searchdata['price2'] ])->links()); ?></div>
					<div class="tab-box  save-search-bar text-center"><a href=""> <i class=" icon-star-empty"></i> Save Search </a></div>

					<div class="pagination-bar text-center">
						<ul class="pagination">
							<li class="active"><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li><a href="#"> ...</a></li>
							<li><a class="pagination-btn" href="#">Next »</a></li>
						</ul>
					</div>
					<!--/.pagination-bar -->

					<div class="post-promo text-center">
						<h2> Do you get anything for sell ? </h2>
						<h5>Sell your products online FOR FREE. It's easier than you think !</h5>
						<a href="<?php echo e(route('post-ads')); ?>" class="btn btn-lg btn-border btn-post btn-danger">Post a Free Ad </a>
					</div>
					<!--/.post-promo-->
				</div><!--/.page-content-->
			</div>
			<!--/.row-->

		</div><!--/.container-->

	</div>
	<!-- /.main-container -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

	<?php /*paceOptions = {*/ ?>
	<?php /*elements: true*/ ?>
	<?php /*};*/ ?>

	<?php /*$('.bxslider').bxSlider({*/ ?>
	<?php /*pagerCustom: '#bx-pager'*/ ?>
	<?php /*});*/ ?>



	<script type="text/javascript">
		jQuery().ready(function () {


		});
	</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js2'); ?>
	<script type="text/javascript">

		$(document).ready(function(){

			var json = <?php echo $json_combo; ?>;

			var htmlstr = '';
			htmlstr += 		'<input type="hidden" data-cat-value="Main Cat" id="combo-main-cat" name="mcategory" value="<?php echo e($searchdata['mcategoryid']); ?>">';
			htmlstr += 		'<input type="hidden" data-cat-sub-value="Sub cat" id="combo-sub-cat" name="category" value="<?php echo e($searchdata['categoryid']); ?>">';
			htmlstr += 		'<span class="combo-span"><i class="fa fa-th"></i> <span>Choose Options</span></span>';
			htmlstr += 		'<ul class="combo-menu">';

			$.each(json, function (key, data) {
				htmlstr += '<li class="has_sub" id="'+key+'" data-cat="'+key+'">';
				flag=0;
				$.each(data, function (index, data2) {
					if(flag==0) {
						htmlstr += '<a href="#" data-value="'+data2.cat+'"><i class="fa fa-car"></i> '+data2.cat+'</a>';
						htmlstr += '<ul class="sub-combo">';
						flag++;
					}
					//console.log('index', index, data2.sid, data2.scat);
					htmlstr += '<li id="'+data2.id+'-'+data2.sid+'" data-cat-sub="'+data2.sid+'"><a href="#" data-value="'+data2.scat+'">'+data2.scat+'</a></li>';
				});
				htmlstr += '</ul></li>';
			});
			htmlstr += '</ul>';
			$('#combo-box-outer').html(htmlstr);
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>