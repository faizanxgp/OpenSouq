<div class="header">
	<nav class="navbar   navbar-site navbar-default" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
					<span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span
							class="icon-bar"></span> <span class="icon-bar"></span>
				</button>
				<a href="<?php echo e(route('home')); ?>" class="navbar-brand logo logo-title">
					<!-- Original Logo will be placed here  --><img alt="img" src="<?php echo e(URL::to('src/images/sab-logo.png')); ?>" class="no-margin img-responsive"><?php /*
          <span class="logo-icon"><i class="icon icon-search-1 ln-shadow-logo shape-0"></i> </span>
          open<span>SOUQ </span>*/ ?>
				</a>
				<div class="flag-lang">
  <span class="flag">
   <img src="https://placeholdit.imgix.net/~text?txtsize=5&amp;txt=30%C3%9720&amp;w=30&amp;h=20&amp;fm=jpg&amp;txtpad=1">
  </span>
					<a href="#">EN</a>
				</div>
			</div>
			<div class="navbar-collapse collapse">

				<ul class="nav navbar-nav navbar-right">
					<?php if(isset($user)): ?>
						<li><a href="">Welcome <?php echo e($user->name); ?></a></li>
						<?php if(($user->roles->first()->id) == 3): ?>
							<li><a href="<?php echo e(route('admin-dashboard')); ?>">Dashboard</a></li>
						<?php else: ?>
							<li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
							<li><a href="<?php echo e(route('messages')); ?>">Messages <span class="label label-warning"><?php echo e($user->hasMessage()); ?></span></a></li>
							<?php /*<?php if(Session::has('messages')): ?> <?php echo e(Session::get('messages')); ?> <?php endif; ?>*/ ?>
							<li><a href="<?php echo e(route('notifications')); ?>">Notifications <span class="label label-warning"><?php echo e($user->hasNotification()); ?></span></a></li>
						<?php endif; ?>

						<li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
					<?php else: ?>
						<li><a href="<?php echo e(route('signin')); ?>">Login</a></li>
						<li><a href="<?php echo e(route('signup')); ?>">Signup</a></li>
					<?php endif; ?>
					<li class="postadd"><a class="btn btn-block btn-border btn-post btn-danger" href="<?php echo e(route('post-ads')); ?>"><i class="fa fa-plus"></i> Post Free Add</a></li>
				</ul>
			</div>
			<!--/.nav-collapse -->
		</div>
		<!-- /.container-fluid -->
	</nav>
</div>
<!-- /.header -->