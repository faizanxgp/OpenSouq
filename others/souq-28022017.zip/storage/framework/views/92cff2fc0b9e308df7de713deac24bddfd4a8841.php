<?php $__env->startSection('content'); ?>
<div class="intro" style="background-image: url(images/bg3.jpg') }});">
    <div class="dtable hw100">
        <div class="dtable-cell hw100">
            <div class="container text-center">
                <h1 class="intro-title animated fadeInDown"> Find Classified Ads </h1>

                <p class="sub animateme fittext3 animated fadeIn"> Find local classified ads on SooqAliBaba in
                    Minutes </p>

                <div class="row search-row animated fadeInUp">
					<form method="post" action="<?php echo e(route('search')); ?>">
						<div class="col-lg-3 col-sm-3 search-col relative locationicon">

							<i class="icon-location-2 icon-append"></i>
							<?php echo e(Form::select('city', $city, null, ['class' => 'form-control', 'placeholder' => 'All Locations', 'id' => 'location'])); ?>


						</div>
						<div class="col-lg-3 col-sm-3 search-col relative locationicon">
							<?php /*<i class="icon-location-2 icon-append"></i>*/ ?>
							<div class="combo-outer" id="combo-box-outer"></div>
							<?php /*<?php echo e(Form::select('category', $subcateg, null, ['class' => 'form-control', 'placeholder' => 'All Categories', 'id' => 'category'])); ?>*/ ?>

						</div>
						<div class="col-lg-5 col-sm-5 search-col relative"><i class="icon-docs icon-append"></i>
							<input type="text" name="searchstr" class="form-control has-icon"
									placeholder="I'm looking for a ..." value="">
						</div>
						<div class="col-lg-1 col-sm-1 search-col">
							<button type="submit" class="btn btn-primary btn-search btn-block"><i
										class="icon-search"></i><strong></strong></button>
							<?php echo e(csrf_field()); ?>

						</div>
					</form>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- /.intro -->
<div class="container">

</div>
<div class="main-container">
    <div class="container">

        <div class="col-lg-12 content-box ">
            <div class="row row-featured row-featured-category">
                <div class="col-lg-12  box-title no-border">
                    <div class="inner"><h2><span>Browse by</span>
                        Category <a href="#" class="sell-your-item"> View more <i
                                class="  icon-th-list"></i> </a></h2>
                    </div>
                </div>


				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/1"><img src="<?php echo e(URL::to('src/images/category/cars-categ.png')); ?>" class="img-responsive" alt="img"> <h6> Cars </h6></a>
				</div>


                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/2"><img src="<?php echo e(URL::to('src/images/category/mobiles-categ.png')); ?>" class="img-responsive" alt="img"> <h6> Mobile & Tablets </h6></a>
                </div>

				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/3"><img src="<?php echo e(URL::to('src/images/category/video-games-categ.png')); ?>" class="img-responsive" alt="img"> <h6> Video Games & Consoles </h6></a>
				</div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/4"><img src="<?php echo e(URL::to('src/images/category/electronics-categ.png')); ?>" class="img-responsive" alt="img"> <h6> Electronics - Appliances </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/5"><img src="<?php echo e(URL::to('src/images/category/realestate-categ.png')); ?>" class="img-responsive" alt="img"> <h6> Real Estate </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/6"><img src="<?php echo e(URL::to('src/images/category/furniture-categ.png')); ?>" class="img-responsive" alt="img"> <h6> Furniture - Decor </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/7"><img src="<?php echo e(URL::to('src/images/category/women-categ.png')); ?>"  class="img-responsive" alt="img"> <h6> Women's Fashion </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/8"><img src="<?php echo e(URL::to('src/images/category/men-categ.png')); ?>" class="img-responsive" alt="img">
                        <h6> Men's Fashion </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/9"><img src="<?php echo e(URL::to('src/images/category/baby-categ.png')); ?>" class="img-responsive" alt="img">
                        <h6> Baby - Kids </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/10"><img src="<?php echo e(URL::to('src/images/category/food-categ.png')); ?>" class="img-responsive" alt="img">
                        <h6> Food Supplements </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/11"><img src="<?php echo e(URL::to('src/images/category/services-categ.png')); ?>" class="img-responsive" alt="img">
                        <h6> Services </h6></a>
                </div>

                <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                    <a href="categories-list/12"><img src="<?php echo e(URL::to('src/images/category/jobs-categ.png')); ?>" class="img-responsive" alt="img">
                        <h6> Jobs </h6></a>
                </div>



				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/14"><img src="<?php echo e(URL::to('src/images/category/pets-categ.png')); ?>" class="img-responsive" alt="img">
						<h6> Pets </h6></a>
				</div>

				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/15"><img src="<?php echo e(URL::to('src/images/category/books-categ.png')); ?>" class="img-responsive" alt="img">
						<h6> Books - Sports - Others </h6></a>
				</div>

				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/16"><img src="<?php echo e(URL::to('src/images/category/business-categ.png')); ?>" class="img-responsive" alt="img">
						<h6> Business Industrial </h6></a>
				</div>

				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/17"><img src="<?php echo e(URL::to('src/images/category/antique-categ.png')); ?>" class="img-responsive" alt="img">
						<h6> Antiques </h6></a>
				</div>

				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/18"><img src="<?php echo e(URL::to('src/images/category/matrimony-categ.png')); ?>" class="img-responsive" alt="img">
						<h6> Matrimony </h6></a>
				</div>

				<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
					<a href="categories-list/19"><img src="<?php echo e(URL::to('src/images/category/jobs-categ.png')); ?>"  class="img-responsive" alt="img"> <h6> Web Services </h6></a>
				</div>

            </div>


        </div>

		<div style="clear: both"></div>

		<div class="col-lg-12 content-box ">
			<div class="row row-featured">
				<div class="col-lg-12  box-title ">
					<div class="inner"><h2><span>Sponsored </span> Products <a href="#" class="sell-your-item"> View more <i class="  icon-th-list"></i> </a></h2>


					</div>
				</div>

				<div style="clear: both"></div>

				<div class=" relative  content featured-list-row clearfix">

					<nav class="slider-nav has-white-bg nav-narrow-svg">
						<a class="prev">
							<span class="nav-icon-wrap"></span>

						</a>
						<a class="next">
							<span class="nav-icon-wrap"></span>
						</a>
					</nav>

					<div class="no-margin featured-list-slider ">
						<div class="item"><a href="#">
                 <span class="item-carousel-thumb">
                    <img class="img-responsive" src="<?php echo e(URL::to('src/images/auto/2012-mercedes-benz-sls-amg.jpg')); ?>" alt="img">
                 </span>
								<span class="item-name"> 2011 Mercedes-Benz SLS AMG  </span>
								<span class="price">  $204,990 </span>
							</a>
						</div>

						<div class="item">

							<a href="#">
                 <span class="item-carousel-thumb">
                    <img class="img-responsive" src="<?php echo e(URL::to('src/images/item/tp/Image00011.jpg')); ?>" alt="img">
                 </span>
								<span class="item-name"> Lorem ipsum dolor sit amet </span>
								<span class="price"> $ 260 </span>
							</a>
						</div>

						<div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img"
										src="<?php echo e(URL::to('src/images/item/tp/Image00006.jpg')); ?>" alt="img"> </span>
								<span class="item-name"> consectetuer adipiscing elit </span>
								<span class="price"> $ 240 </span></a></div>


						<div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img"
										src="<?php echo e(URL::to('src/images/item/tp/Image00022.jpg')); ?>" alt="img"> </span>
								<span class="item-name"> sed diam nonummy  </span> <span class="price"> $ 140</span></a>
						</div>

						<div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img"
										src="<?php echo e(URL::to('src/images/item/tp/Image00013.jpg')); ?>" alt="img">  </span><span
										class="item-name"> feugiat nulla facilisis  </span> <span
										class="price"> $ 140 </span></a></div>

						<div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img" src="<?php echo e(URL::to('src/images/item/3.jpg')); ?>"
										alt="img"> </span> <span class="item-name"> praesent luptatum zzril  </span>
								<span class="price"> $ 220 </span></a></div>

						<div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img" src="<?php echo e(URL::to('src/images/item/4.jpg')); ?>"
										alt="img"> </span> <span class="item-name"> delenit augue duis dolore  </span>
								<span class="price"> $ 120 </span></a></div>

						<div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img" src="<?php echo e(URL::to('src/images/item/6.jpg')); ?>"
										alt="img"> </span> <span class="item-name"> te feugait nulla facilisi </span>
								<span class="price"> $ 251 </span></a></div>
					</div>


				</div>

			</div>
		</div>

        <div style="clear: both"></div>

        <div class="col-lg-12 content-box ">
            <div class="row row-featured">
                <div class="col-lg-12  box-title ">
                    <div class="inner"><h2><span>Latest </span> Products <a href="#" class="sell-your-item"> View more <i class="  icon-th-list"></i> </a></h2>


                    </div>
                </div>

                <div style="clear: both"></div>

                <div class=" relative  content featured-list-row2
                 clearfix">

                    <nav class="slider-nav has-white-bg nav-narrow-svg">
                        <a class="prev">
                            <span class="nav-icon-wrap"></span>

                        </a>
                        <a class="next">
                            <span class="nav-icon-wrap"></span>
                        </a>
                    </nav>

                    <div class="no-margin featured-list-slider2 recent-list-slider ">
                        <div class="item"><a href="#">
                 <span class="item-carousel-thumb">
                    <img class="img-responsive" src="<?php echo e(URL::to('src/images/auto/2012-mercedes-benz-sls-amg.jpg')); ?>" alt="img">
                 </span>
                            <span class="item-name"> 2011 Mercedes-Benz SLS AMG  </span>
                            <span class="price">  $204,990 </span>
                        </a>
                        </div>

                        <div class="item">

                            <a href="#">
                 <span class="item-carousel-thumb">
                    <img class="img-responsive" src="<?php echo e(URL::to('src/images/item/tp/Image00011.jpg')); ?>" alt="img">
                 </span>
                                <span class="item-name"> Lorem ipsum dolor sit amet </span>
                                <span class="price"> $ 260 </span>
                            </a>
                        </div>

                        <div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img"
                                                                    src="<?php echo e(URL::to('src/images/item/tp/Image00006.jpg')); ?>" alt="img"> </span>
                            <span class="item-name"> consectetuer adipiscing elit </span>
                            <span class="price"> $ 240 </span></a></div>


                        <div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img"
                                                                    src="<?php echo e(URL::to('src/images/item/tp/Image00022.jpg')); ?>" alt="img"> </span>
                            <span class="item-name"> sed diam nonummy  </span> <span class="price"> $ 140</span></a>
                        </div>

                        <div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img"
                                                                    src="<?php echo e(URL::to('src/images/item/tp/Image00013.jpg')); ?>" alt="img">  </span><span
                                class="item-name"> feugiat nulla facilisis  </span> <span
                                class="price"> $ 140 </span></a></div>

                        <div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img" src="<?php echo e(URL::to('src/images/item/3.jpg')); ?>"
                                                                    alt="img"> </span> <span class="item-name"> praesent luptatum zzril  </span>
                            <span class="price"> $ 220 </span></a></div>

                        <div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img" src="<?php echo e(URL::to('src/images/item/4.jpg')); ?>"
                                                                    alt="img"> </span> <span class="item-name"> delenit augue duis dolore  </span>
                            <span class="price"> $ 120 </span></a></div>

                        <div class="item"><a href="#">
                            <span class="item-carousel-thumb"> <img class="item-img" src="<?php echo e(URL::to('src/images/item/6.jpg')); ?>"
                                                                    alt="img"> </span> <span class="item-name"> te feugait nulla facilisi </span>
                            <span class="price"> $ 251 </span></a></div>
                    </div>


                </div>

            </div>
        </div>


        <div class="col-lg-12 content-box ">
            <div class="row row-featured">

                <div style="clear: both"></div>

                <div class=" relative  content  clearfix">


                    <?php /*<div class="">*/ ?>
                        <?php /*<div class="tab-lite">*/ ?>

                            <?php /*<!-- Nav tabs -->*/ ?>
                            <?php /*<ul class="nav nav-tabs " role="tablist">*/ ?>
                                <?php /*<li role="presentation" class="active"><a href="#tab1" aria-controls="tab1"*/ ?>
                                                                          <?php /*role="tab" data-toggle="tab"><i*/ ?>
                                        <?php /*class="icon-location-2"></i> Top Locations</a></li>*/ ?>
                                <?php /*<li role="presentation"><a href="#tab2" aria-controls="tab2" role="tab"*/ ?>
                                                           <?php /*data-toggle="tab"><i class="icon-search"></i> Top Search</a>*/ ?>
                                <?php /*</li>*/ ?>
                                <?php /*<li role="presentation"><a href="#tab3" aria-controls="tab3" role="tab"*/ ?>
                                                           <?php /*data-toggle="tab"><i class="icon-th-list"></i> Top Makes</a>*/ ?>
                                <?php /*</li>*/ ?>
                            <?php /*</ul>*/ ?>

                            <?php /*<!-- Tab panes -->*/ ?>
                            <?php /*<div class="tab-content">*/ ?>
                                <?php /*<div role="tabpanel" class="tab-pane active" id="tab1">*/ ?>

                                    <?php /*<div class="col-lg-12 tab-inner">*/ ?>

                                        <?php /*<div class="row">*/ ?>
                                            <?php /*<ul class="cat-list col-sm-3  col-xs-6 col-xxs-12">*/ ?>
												<?php /*<?php foreach($city as $row): ?>*/ ?>
                                                <?php /*<li><a href="#"><?php echo e($row); ?></a></li>*/ ?>
												<?php /*<?php endforeach; ?>*/ ?>
                                                <?php /*<li><a href="#"> Dallas </a></li>*/ ?>
                                                <?php /*<li><a href="#"> New York </a></li>*/ ?>
                                                <?php /*<li><a href="#">Santa Ana/Anaheim </a></li>*/ ?>
                                                <?php /*<li><a href="#">Wichita </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Anchorage </a></li>*/ ?>

                                                <?php /*<li><a href="#"> Miami </a></li>*/ ?>
                                                <?php /*<li><a href="#">Los Angeles</a></li>*/ ?>
                                            <?php /*</ul>*/ ?>

                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>

                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>

                                            <?php /*</ul>*/ ?>

                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>


                                            <?php /*</ul>*/ ?>

                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>

                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>

                                            <?php /*</ul>*/ ?>

                                        <?php /*</div>*/ ?>

                                    <?php /*</div>*/ ?>


                                <?php /*</div>*/ ?>
                                <?php /*<div role="tabpanel" class="tab-pane" id="tab2">*/ ?>

                                    <?php /*<div class="col-lg-12 tab-inner">*/ ?>

                                        <?php /*<div class="row">*/ ?>

                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>

                                            <?php /*</ul>*/ ?>


                                            <?php /*<ul class="cat-list col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Atlanta</a></li>*/ ?>
                                                <?php /*<li><a href="#">Wichita </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Anchorage </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Dallas </a></li>*/ ?>
                                                <?php /*<li><a href="#"> New York </a></li>*/ ?>
                                                <?php /*<li><a href="#">Santa Ana/Anaheim </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Miami </a></li>*/ ?>
                                                <?php /*<li><a href="#">Los Angeles</a></li>*/ ?>
                                            <?php /*</ul>*/ ?>

                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>

                                            <?php /*</ul>*/ ?>

                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>

                                            <?php /*</ul>*/ ?>


                                        <?php /*</div>*/ ?>

                                    <?php /*</div>*/ ?>


                                <?php /*</div>*/ ?>
                                <?php /*<div role="tabpanel" class="tab-pane" id="tab3">*/ ?>

                                    <?php /*<div class="col-lg-12 tab-inner">*/ ?>

                                        <?php /*<div class="row">*/ ?>


                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>

                                            <?php /*</ul>*/ ?>


                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>

                                            <?php /*</ul>*/ ?>


                                            <?php /*<ul class="cat-list col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Atlanta</a></li>*/ ?>
                                                <?php /*<li><a href="#">Wichita </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Anchorage </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Dallas </a></li>*/ ?>
                                                <?php /*<li><a href="#"> New York </a></li>*/ ?>
                                                <?php /*<li><a href="#">Santa Ana/Anaheim </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Miami </a></li>*/ ?>
                                                <?php /*<li><a href="#">Los Angeles</a></li>*/ ?>
                                            <?php /*</ul>*/ ?>

                                            <?php /*<ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">*/ ?>
                                                <?php /*<li><a href="#">Virginia Beach </a></li>*/ ?>
                                                <?php /*<li><a href="#"> San Diego </a></li>*/ ?>
                                                <?php /*<li><a href="#">Boston </a></li>*/ ?>
                                                <?php /*<li><a href="#">Houston</a></li>*/ ?>
                                                <?php /*<li><a href="#">Salt Lake City </a></li>*/ ?>
                                                <?php /*<li><a href="#">San Francisco </a></li>*/ ?>
                                                <?php /*<li><a href="#">Tampa </a></li>*/ ?>
                                                <?php /*<li><a href="#"> Washington DC </a></li>*/ ?>

                                            <?php /*</ul>*/ ?>


                                        <?php /*</div>*/ ?>

                                    <?php /*</div>*/ ?>


                                <?php /*</div>*/ ?>
                            <?php /*</div>*/ ?>

                        <?php /*</div>*/ ?>

                    <?php /*</div>*/ ?>


                </div>

            </div>
        </div>


        <?php /*<div class="row">*/ ?>


            <?php /*<div class="col-sm-9 page-content col-thin-right">*/ ?>
                <?php /*<div class="inner-box category-content">*/ ?>
                    <?php /*<h2 class="title-2">Find Classified Ads World Wide </h2>*/ ?>

                    <?php /*<div class="row">*/ ?>
                        <?php /*<div class="col-md-4 col-sm-4 ">*/ ?>
                            <?php /*<div class="cat-list">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i class="fa fa-car ln-shadow"></i>*/ ?>
                                    <?php /*Automobiles <span class="count">277,959</span> </a>*/ ?>

                                    <?php /*<span data-target=".cat-id-1" data-toggle="collapse"*/ ?>
                                          <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                            <?php /*class=" icon-down-open-big"></span> </span>*/ ?>
                                <?php /*</h3>*/ ?>
                                <?php /*<ul class="cat-collapse collapse in cat-id-1">*/ ?>
                                    <?php /*<li><a href="#">Car Parts &amp; Accessories</a></li>*/ ?>
                                    <?php /*<li><a href="#">Campervans &amp; Caravans</a></li>*/ ?>
                                    <?php /*<li><a href="#">Motorbikes &amp; Scooters</a></li>*/ ?>
                                    <?php /*<li><a href="#">Motorbike Parts &amp; Accessories</a></li>*/ ?>
                                    <?php /*<li><a href="#">Vans, Trucks &amp; Plant</a></li>*/ ?>
                                    <?php /*<li><a href="#">Wanted</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="cat-list">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i class="icon-home ln-shadow"></i>*/ ?>
                                    <?php /*Property <span class="count">228,705</span></a> <span data-target=".cat-id-2"*/ ?>
                                                                                          <?php /*data-toggle="collapse"*/ ?>
                                                                                          <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                        <?php /*class=" icon-down-open-big"></span> </span></h3>*/ ?>


                                <?php /*<ul class="cat-collapse collapse in cat-id-2">*/ ?>
                                    <?php /*<li><a href="#">House for Rent</a></li>*/ ?>
                                    <?php /*<li><a href="#">House for Sale </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Apartments For Sale </a></li>*/ ?>
                                    <?php /*<li><a href="#">Apartments for Rent </a></li>*/ ?>
                                    <?php /*<li><a href="#">Farms-Ranches </a></li>*/ ?>
                                    <?php /*<li><a href="#">Land </a></li>*/ ?>
                                    <?php /*<li><a href="#">Vacation Rentals </a></li>*/ ?>
                                    <?php /*<li><a href="#">Commercial Building</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="cat-list">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i class="icon-home ln-shadow"></i>*/ ?>
                                    <?php /*Jobs <span class="count">6375</span></a>*/ ?>

                                    <?php /*<span data-target=".cat-id-3" data-toggle="collapse"*/ ?>
                                          <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                            <?php /*class=" icon-down-open-big"></span> </span>*/ ?>
                                <?php /*</h3>*/ ?>
                                <?php /*<ul class="cat-collapse collapse in cat-id-3">*/ ?>
                                    <?php /*<li><a href="#">Full Time Jobs</a></li>*/ ?>
                                    <?php /*<li><a href="#">Internet Jobs </a></li>*/ ?>
                                    <?php /*<li><a href="#">Learn &amp; Earn jobs </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Manual Labor Jobs </a></li>*/ ?>
                                    <?php /*<li><a href="#">Other Jobs </a></li>*/ ?>
                                    <?php /*<li><a href="#">OwnBusiness </a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-4 col-sm-4">*/ ?>
                            <?php /*<div class="cat-list">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i*/ ?>
                                        <?php /*class="fa fa-briefcase ln-shadow"></i> Services <span*/ ?>
                                        <?php /*class="count">45,526</span></a>*/ ?>
                                    <?php /*<span data-target=".cat-id-4" data-toggle="collapse"*/ ?>
                                          <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                            <?php /*class=" icon-down-open-big"></span> </span>*/ ?>
                                <?php /*</h3>*/ ?>
                                <?php /*<ul class="cat-collapse collapse in cat-id-4">*/ ?>
                                    <?php /*<li><a href="#">Building, Home &amp; Removals</a></li>*/ ?>
                                    <?php /*<li><a href="#">Entertainment</a></li>*/ ?>
                                    <?php /*<li><a href="#">Health &amp; Beauty</a></li>*/ ?>
                                    <?php /*<li><a href="#">Miscellaneous</a></li>*/ ?>
                                    <?php /*<li><a href="#">Property &amp; Shipping</a></li>*/ ?>
                                    <?php /*<li><a href="#">Tax, Money &amp; Visas</a></li>*/ ?>
                                    <?php /*<li><a href="#">Telecoms &amp; Computers</a></li>*/ ?>
                                    <?php /*<li><a href="#">Travel Services &amp; Tours</a></li>*/ ?>
                                    <?php /*<li><a href="#">Tuition &amp; Lessons</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="cat-list">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i*/ ?>
                                        <?php /*class="icon-book-open ln-shadow"></i> Learning <span*/ ?>
                                        <?php /*class="count">26,529</span></a> <span data-target=".cat-id-5"*/ ?>
                                                                              <?php /*data-toggle="collapse"*/ ?>
                                                                              <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                        <?php /*class=" icon-down-open-big"></span> </span>*/ ?>
                                <?php /*</h3>*/ ?>
                                <?php /*<ul class="cat-collapse collapse in cat-id-5">*/ ?>
                                    <?php /*<li><a href="#"> Automotive Classes </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Computer Multimedia Classes </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Sports Classes </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Home Improvement Classes </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Language Classes </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Music Classes </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Personal Fitness </a></li>*/ ?>
                                    <?php /*<li><a href="#"> Other Classes </a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="cat-list">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i*/ ?>
                                        <?php /*class="icon-guidedog ln-shadow"></i> Pets <span class="count">42,111</span></a>*/ ?>
                                    <?php /*<span data-target=".cat-id-6" data-toggle="collapse"*/ ?>
                                          <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                            <?php /*class=" icon-down-open-big"></span> </span>*/ ?>
                                <?php /*</h3>*/ ?>
                                <?php /*<ul class="cat-collapse collapse in cat-id-6">*/ ?>
                                    <?php /*<li><a href="#">Pets for Sale</a></li>*/ ?>
                                    <?php /*<li><a href="#">Petsitters &amp; Dogwalkers</a></li>*/ ?>
                                    <?php /*<li><a href="#">Equipment &amp; Accessories</a></li>*/ ?>
                                    <?php /*<li><a href="#">Missing, Lost &amp; Found</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-4 col-sm-4   last-column">*/ ?>
                            <?php /*<div class="cat-list">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i*/ ?>
                                        <?php /*class=" icon-basket-1 ln-shadow"></i> For Sale <span*/ ?>
                                        <?php /*class="count">64,526</span></a> <span data-target=".cat-id-7"*/ ?>
                                                                              <?php /*data-toggle="collapse"*/ ?>
                                                                              <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                        <?php /*class=" icon-down-open-big"></span> </span>*/ ?>
                                <?php /*</h3>*/ ?>
                                <?php /*<ul class="cat-collapse collapse in cat-id-7">*/ ?>
                                    <?php /*<li><a href="#">Audio &amp; Stereo</a></li>*/ ?>
                                    <?php /*<li><a href="#">Baby &amp; Kids Stuff</a></li>*/ ?>
                                    <?php /*<li><a href="#">CDs, DVDs, Games &amp; Books</a></li>*/ ?>
                                    <?php /*<li><a href="#">Clothes, Footwear &amp; Accessories</a></li>*/ ?>
                                    <?php /*<li><a href="#">Computers &amp; Software</a></li>*/ ?>
                                    <?php /*<li><a href="#">Home &amp; Garden</a></li>*/ ?>
                                    <?php /*<li><a href="#">Music &amp; Instruments</a></li>*/ ?>
                                    <?php /*<li><a href="#">Office Furniture &amp; Equipment</a></li>*/ ?>
                                    <?php /*<li><a href="#">Phones, Mobile Phones &amp; Telecoms</a></li>*/ ?>
                                    <?php /*<li><a href="#">Sports, Leisure &amp; Travel</a></li>*/ ?>
                                    <?php /*<li><a href="#">Tickets</a></li>*/ ?>
                                    <?php /*<li><a href="#">TV, DVD &amp; Cameras</a></li>*/ ?>
                                    <?php /*<li><a href="#">Video Games &amp; Consoles</a></li>*/ ?>
                                    <?php /*<li><a href="#">Freebies</a></li>*/ ?>
                                    <?php /*<li><a href="#">Miscellaneous Goods</a></li>*/ ?>
                                    <?php /*<li><a href="#">Stuff Wanted</a></li>*/ ?>
                                    <?php /*<li><a href="#">Swap Shop</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="cat-list ">*/ ?>
                                <?php /*<h3 class="cat-title"><a href="#"><i*/ ?>
                                        <?php /*class=" icon-theatre ln-shadow"></i> Community <span*/ ?>
                                        <?php /*class="count">5,30</span> </a> <span data-target=".cat-id-8"*/ ?>
                                                                             <?php /*data-toggle="collapse"*/ ?>
                                                                             <?php /*class="btn-cat-collapsed collapsed">   <span*/ ?>
                                        <?php /*class=" icon-down-open-big"></span> </span>*/ ?>
                                <?php /*</h3>*/ ?>
                                <?php /*<ul class="cat-collapse collapse in cat-id-8">*/ ?>
                                    <?php /*<li><a href="#">Announcements </a></li>*/ ?>
                                    <?php /*<li><a href="#">Car Pool - Bike Ride </a></li>*/ ?>
                                    <?php /*<li><a href="#">Charity - Donate - NGO </a></li>*/ ?>
                                    <?php /*<li><a href="#">Lost - Found </a></li>*/ ?>
                                    <?php /*<li><a href="#">Tender Notices </a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>

                <?php /*<div class="inner-box has-aff relative">*/ ?>
                    <?php /*<a class="dummy-aff-img" href="#"><img src="<?php echo e(URL::to('src/images/aff2.jpg')); ?>" class="img-responsive"*/ ?>
                                                                       <?php /*alt=" aff"> </a>*/ ?>

                <?php /*</div>*/ ?>
            <?php /*</div>*/ ?>
            <?php /*<div class="col-sm-3 page-sidebar col-thin-left">*/ ?>
                <?php /*<aside>*/ ?>
                    <?php /*<div class="inner-box no-padding">*/ ?>
                        <?php /*<div class="inner-box-content"><a href="#"><img class="img-responsive"*/ ?>
                                                                        <?php /*src=<?php echo e(URL::to('src/images/site/app.jpg')); ?>" alt="tv"></a>*/ ?>
                        <?php /*</div>*/ ?>
                    <?php /*</div>*/ ?>
                    <?php /*<div class="inner-box">*/ ?>
                        <?php /*<h2 class="title-2">Popular Categories </h2>*/ ?>

                        <?php /*<div class="inner-box-content">*/ ?>
                            <?php /*<ul class="cat-list arrow">*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Apparel (1,386) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Art (1,163) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Business Opportunities (4,974) </a>*/ ?>
                                <?php /*</li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Community and Events (1,258) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Electronics and Appliances*/ ?>
                                    <?php /*(1,578) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Jobs and Employment (3,609) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Motorcycles (968) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Pets (1,188) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Services (7,583) </a></li>*/ ?>
                                <?php /*<li><a href="sub-category-sub-location.html"> Vehicles (1,129) </a></li>*/ ?>
                            <?php /*</ul>*/ ?>
                        <?php /*</div>*/ ?>
                    <?php /*</div>*/ ?>

                    <?php /*<div class="inner-box no-padding"><img class="img-responsive" src=<?php echo e(URL::to('src/images/add2.jpg')); ?>" alt="">*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</aside>*/ ?>
            <?php /*</div>*/ ?>
        <?php /*</div>*/ ?>
    </div>
</div>
<!-- /.main-container -->

<?php /*<div class="page-info hasOverly" style="background: url(images/bg.jpg') }}); background-size:cover">*/ ?>
    <?php /*<div class="bg-overly">*/ ?>
        <?php /*<div class="container text-center section-promo">*/ ?>
            <?php /*<div class="row">*/ ?>
                <?php /*<div class="col-sm-3 col-xs-6 col-xxs-12">*/ ?>
                    <?php /*<div class="iconbox-wrap">*/ ?>
                        <?php /*<div class="iconbox">*/ ?>
                            <?php /*<div class="iconbox-wrap-icon">*/ ?>
                                <?php /*<i class="icon  icon-group"></i>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="iconbox-wrap-content">*/ ?>
                                <?php /*<h5><span>2200</span></h5>*/ ?>

                                <?php /*<div class="iconbox-wrap-text">Trusted Seller</div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<!-- /..iconbox -->*/ ?>
                    <?php /*</div>*/ ?>
                    <?php /*<!--/.iconbox-wrap-->*/ ?>
                <?php /*</div>*/ ?>

                <?php /*<div class="col-sm-3 col-xs-6 col-xxs-12">*/ ?>
                    <?php /*<div class="iconbox-wrap">*/ ?>
                        <?php /*<div class="iconbox">*/ ?>
                            <?php /*<div class="iconbox-wrap-icon">*/ ?>
                                <?php /*<i class="icon  icon-th-large-1"></i>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="iconbox-wrap-content">*/ ?>
                                <?php /*<h5><span>100</span></h5>*/ ?>

                                <?php /*<div class="iconbox-wrap-text">Categories</div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<!-- /..iconbox -->*/ ?>
                    <?php /*</div>*/ ?>
                    <?php /*<!--/.iconbox-wrap-->*/ ?>
                <?php /*</div>*/ ?>

                <?php /*<div class="col-sm-3 col-xs-6  col-xxs-12">*/ ?>
                    <?php /*<div class="iconbox-wrap">*/ ?>
                        <?php /*<div class="iconbox">*/ ?>
                            <?php /*<div class="iconbox-wrap-icon">*/ ?>
                                <?php /*<i class="icon  icon-map"></i>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="iconbox-wrap-content">*/ ?>
                                <?php /*<h5><span>700</span></h5>*/ ?>

                                <?php /*<div class="iconbox-wrap-text">Location</div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<!-- /..iconbox -->*/ ?>
                    <?php /*</div>*/ ?>
                    <?php /*<!--/.iconbox-wrap-->*/ ?>
                <?php /*</div>*/ ?>

                <?php /*<div class="col-sm-3 col-xs-6 col-xxs-12">*/ ?>
                    <?php /*<div class="iconbox-wrap">*/ ?>
                        <?php /*<div class="iconbox">*/ ?>
                            <?php /*<div class="iconbox-wrap-icon">*/ ?>
                                <?php /*<i class="icon icon-facebook"></i>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="iconbox-wrap-content">*/ ?>
                                <?php /*<h5><span>50,000</span></h5>*/ ?>

                                <?php /*<div class="iconbox-wrap-text"> Facebook Fans</div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<!-- /..iconbox -->*/ ?>
                    <?php /*</div>*/ ?>
                    <?php /*<!--/.iconbox-wrap-->*/ ?>
                <?php /*</div>*/ ?>

            <?php /*</div>*/ ?>

        <?php /*</div>*/ ?>
    <?php /*</div>*/ ?>
<?php /*</div>*/ ?>
<!-- /.page-info -->

<div class="page-bottom-info">
    <div class="page-bottom-info-inner">

        <div class="page-bottom-info-content text-center">
            <h1>If you have any questions, comments or concerns, please call the Classified Advertising department
                at (000) 555-5555</h1>
            <a class="btn  btn-lg btn-primary-dark" href="tel:+000000000">
                <i class="icon-mobile"></i> <span class="hide-xs color50">Call Now:</span> (000) 555-5555 </a>
        </div>

    </div>
</div>

<?php if(Session::has('flash_message')): ?>
<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title">Notification</h4>
			</div>
			<div class="modal-body">
				<p><?php echo e(Session::get('flash_message')); ?></p>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js2'); ?>
	<script type="text/javascript">

		$(document).ready(function(){

			<?php if(Session::has('flash_message')): ?>
				$("#myModal").modal('show');
			<?php endif; ?>

			var json = <?php echo $json_combo; ?>;

			var htmlstr = '';
			htmlstr += 		'<input type="hidden" data-cat-value="Main Cat" id="combo-main-cat" name="mcategory" value="0">';
			htmlstr += 		'<input type="hidden" data-cat-sub-value="Sub cat" id="combo-sub-cat" name="category" value="0">';
			htmlstr += 		'<span class="combo-span"><i class="fa fa-th"></i> <span>Choose Options</span></span>';
			htmlstr += 		'<ul class="combo-menu">';

			$.each(json, function (key, data) {
				htmlstr += '<li class="has_sub" id="'+key+'" data-cat="'+key+'">';
				flag=0;
				$.each(data, function (index, data2) {
					if(flag==0) {
						htmlstr += '<a href="#" data-value="'+data2.cat+'"><i class="fa fa-car"></i> '+data2.cat+'</a>';
						htmlstr += '<ul class="sub-combo">';
						flag++;
					}
					//console.log('index', index, data2.sid, data2.scat);
					htmlstr += '<li id="'+data2.id+'-'+data2.sid+'" data-cat-sub="'+data2.sid+'"><a href="#" data-value="'+data2.scat+'">'+data2.scat+'</a></li>';
				});
				htmlstr += '</ul></li>';
			});
			htmlstr += '</ul>';
			$('#combo-box-outer').html(htmlstr);
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>